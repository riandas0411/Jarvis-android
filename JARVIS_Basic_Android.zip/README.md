# JARVIS Basic Android

This is a simple offline starter JARVIS app.

Features:
- Voice recognition
- Text-to-speech
- Time/date responses
- Opens Google and YouTube
- Hindi speech recognition mode

How to run:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Connect an Android phone with USB debugging enabled, or use an emulator.
4. Press Run.
5. Allow microphone permission.
6. Tap TALK TO JARVIS.

This starter does not use an online AI API yet. The next version can add a secure AI backend.
