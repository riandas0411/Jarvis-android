package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private val voiceRequest = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        tts = TextToSpeech(this, this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 80, 40, 40)
        }

        val title = TextView(this).apply {
            text = "J.A.R.V.I.S"
            textSize = 32f
            setPadding(0, 0, 0, 30)
        }

        status = TextView(this).apply {
            text = "Ready. Tap the button and speak."
            textSize = 20f
            setPadding(0, 0, 0, 40)
        }

        val button = Button(this).apply {
            text = "🎤 TALK TO JARVIS"
            setOnClickListener { startListening() }
        }

        layout.addView(title)
        layout.addView(status)
        layout.addView(button)
        setContentView(layout)

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS is listening...")
        }
        try {
            startActivityForResult(intent, voiceRequest)
        } catch (e: Exception) {
            status.text = "Voice recognition is not available on this phone."
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != voiceRequest || resultCode != RESULT_OK) return

        val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
        status.text = "You: $text"
        val answer = makeResponse(text.lowercase(Locale.getDefault()))
        status.text = "You: $text\n\nJARVIS: $answer"
        speak(answer)
    }

    private fun makeResponse(text: String): String {
        return when {
            text.contains("time") || text.contains("समय") || text.contains("সময়") ->
                "The time is " + SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            text.contains("date") || text.contains("तारीख") || text.contains("তারিখ") ->
                "Today is " + SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(Date())
            text.contains("hello") || text.contains("हेलो") || text.contains("হ্যালো") ->
                "Hello. I am JARVIS. How can I help you?"
            text.contains("youtube") -> {
                startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.youtube.com")))
                "Opening YouTube."
            }
            text.contains("google") -> {
                startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com")))
                "Opening Google."
            }
            else -> "I heard you say: $text. My basic offline mode cannot answer that yet."
        }
    }

    private fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale.US
        }
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}
